#ifndef ENCODEX_FLUX_CODEC_H
#define ENCODEX_FLUX_CODEC_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* FluxNum v1: reversible randomized alphabet and CRC-32, NOT encryption.
   Caller owns returned *digits / *output and must free() it. */
int flux_encode(const unsigned char *data, size_t length, int base,
                const char *nonce8, char **digits, uint32_t *checksum);
int flux_decode(int base, const char *nonce8, const char *digits,
                size_t count, uint32_t expected_crc, unsigned char **output);
uint32_t flux_crc32(const unsigned char *data, size_t length);
int flux_digit_width(int base);
#ifdef __cplusplus
}
#endif
#endif
