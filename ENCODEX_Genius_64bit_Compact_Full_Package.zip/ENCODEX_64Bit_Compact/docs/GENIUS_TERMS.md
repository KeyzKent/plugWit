# GENIUS Terms / analogy-based mini-language

The GENIUS mini-language is a small, executable command vocabulary. It is **not** a new general-purpose compiler, sentient intelligence, or a programming language that magically compiles C/Java/Objective-C. Its purpose is to coordinate reusable actions through metaphors and JSON APIs.

| Term | Analogy | Actual implementation | Example |
|---|---|---|---|
| `LENS` | looking through a lens | indexed local keyword search | `LENS USB-C sensor` |
| `FORGE` | forging an object | grounded project-text synthesis | `FORGE build robotics sensor adapter` |
| `MIRROR` | reflection | describes a subsystem using a bridge analogy | `MIRROR numerical bus` |
| `FLUX` | moving signals | summary statistics, normalization, seeded shuffle | `FLUX 2 3 5 8 13` |
| `TRAIN` | teaching | save a labeled Naive Bayes training example | `TRAIN robotics | camera servo movement` |
| `CLASSIFY` | recognizing | multinomial Naive Bayes prediction | `CLASSIFY camera servo movement` |
| `ROUTE` | bus routing | append **virtual** JSON event to in-memory log | `ROUTE robot | {"sensor":0.5}` |
| `SNAP` | taking a snapshot | save a backend checkpoint | `SNAP prototype` |

`FORGE` uses existing local project documentation to draft a response. It does **not** query the public internet, execute an LLM, generate working compilation artifacts, or learn continuously without explicit examples. The `TRAIN`/`CLASSIFY` functionality uses a transparent text classifier with persisted training examples; the older visual-vector robot training module remains separate.

## Interoperability

The Python HTTP API provides `/api/search`, `/api/generate`, `/api/command`, `/api/numeric`, `/api/codec`, `/api/train`, `/api/classify`, `/api/route`, `/api/snap`, and read-only `/api/events` and `/api/health`.

`/api/codec` uses the **unchanged** FluxNum v1 JSON packet (`v`, `base`, `nonce`, `count`, `digits`, `crc32`). This matches the previous browser and RP2040 CircuitPython firmware. It is an encoding format, **not encryption**.

Architecture:

```
                          LOCAL GENIUS PYTHON API
     LENS → retrieved documentation → FORGE → design draft
      ↑                                     ↓
 UI search/generative bars                  FLUX / codec
      ↑                                     ↓
 HTML + CSS + JS  ←  dashboard  ←  virtual ROUTE + SNAP
      │                                      │
      ├─ existing media/robotics/haptic/spectrum/world/IDE modules
      └─ optional verified USB CDC firmware (only existing v1 commands)
```

Physical GPIO, motor actuation, USB power, USB-C e-marker or Power Delivery controls are **not** implemented by the new APIs.
