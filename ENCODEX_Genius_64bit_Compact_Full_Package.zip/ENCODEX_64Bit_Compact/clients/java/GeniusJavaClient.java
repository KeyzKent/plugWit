import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
/* JDK 11+. Real localhost GENIUS backend client, prints API JSON response. */
public class GeniusJavaClient {
    static final String API = System.getenv("ENCODEX_API") == null ? "http://127.0.0.1:8765" : System.getenv("ENCODEX_API");
    static String jsonQuote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }
    static String call(String path, String json) throws Exception {
        HttpRequest.Builder builder=HttpRequest.newBuilder(URI.create(API+path));
        if (json == null) builder.GET();
        else builder.header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8));
        HttpResponse<String> response=HttpClient.newHttpClient().send(builder.build(),HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()!=200)throw new RuntimeException("HTTP "+response.statusCode()+": "+response.body());
        return response.body();
    }
    public static void main(String[] args) throws Exception {
        String task=args.length>0?args[0]:"search";
        String phrase=args.length>1?args[1]:"USB-C robotics camera sensor";
        String result;
        switch(task){
            case "search": result=call("/api/search?q="+URLEncoder.encode(phrase,StandardCharsets.UTF_8),null);break;
            case "forge": result=call("/api/generate","{\"prompt\":"+jsonQuote(phrase)+"}");break;
            case "command": result=call("/api/command","{\"expression\":"+jsonQuote(phrase)+"}");break;
            default: throw new IllegalArgumentException("Use search, forge or command");
        }
        System.out.println(result);
    }
}
