"""Run: python -m unittest discover -s tests -v"""
import sys
from pathlib import Path
import unittest
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "firmware"))
from packet_codec import encode, decode, crc32, shuffled_alphabet, digit_width


class FluxNumCodecTests(unittest.TestCase):
    def test_widths(self):
        self.assertEqual([digit_width(x) for x in (2, 8, 10, 16)], [8, 3, 3, 2])

    def test_crc_standard(self):
        self.assertEqual(crc32(b"123456789"), 0xCBF43926)
        self.assertEqual(crc32(bytes(range(256))), zlib.crc32(bytes(range(256))))

    def test_all_bases_binary_roundtrip(self):
        for base in (2, 8, 10, 16):
            for data in (b"", b"hello", "hello 🌐 漢字".encode(), bytes(range(256))):
                packet = encode(data, base, "1234abcd")
                self.assertEqual(decode(packet), data)
                self.assertEqual(len(packet["digits"]), packet["count"] * digit_width(base))

    def test_randomized_nonces(self):
        data = b"firmware"
        variants = {encode(data, 10)["nonce"] for _ in range(30)}
        self.assertGreater(len(variants), 25)

    def test_checksum_rejects_tampered_payload(self):
        packet = encode(b"test", 16, "deadbeef")
        packet["digits"] = packet["digits"][:-1] + ("0" if packet["digits"][-1] != "0" else "1")
        with self.assertRaises(ValueError):
            decode(packet)

    def test_invalid_length(self):
        packet = encode(b"abc", 10, "abababab")
        packet["count"] += 1
        with self.assertRaises(ValueError):
            decode(packet)

    def test_alphabet_permutation(self):
        for base in (2, 8, 10, 16):
            for nonce in ("00000000", "ffffffff", "1234abcd"):
                alpha = shuffled_alphabet(base, nonce)
                self.assertEqual(sorted(alpha), sorted("0123456789ABCDEF"[:base]))


if __name__ == "__main__":
    unittest.main()
