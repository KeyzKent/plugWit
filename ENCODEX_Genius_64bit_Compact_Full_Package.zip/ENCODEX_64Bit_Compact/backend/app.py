"""Local-only ENCODEX 64-Bit API + static single-HTML GUI. Python 3.10+."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import argparse
import json
from backend.engine import GeniusEngine, ROOT, ANALOGIES
from backend.int64 import transform

class Handler(SimpleHTTPRequestHandler):
    engine = None
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _json(self, result, code=200):
        payload = json.dumps(result, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        request = urlparse(self.path)
        path = request.path
        if path in ('/', '/index.html'):
            self.send_response(302)
            self.send_header('Location', '/frontend/index.html')
            self.end_headers()
            return
        if path.startswith('/api/'):
            try:
                query = parse_qs(request.query)
                if path == '/api/health':
                    result = {'ok':True,'version':'64-bit compact 1.0',
                              'architecture':'64-bit exact word arithmetic',
                              'docs':len(self.engine.documents),
                              'training_count':len(self.engine.trainer.examples),
                              'commands':list(ANALOGIES)}
                elif path == '/api/search':
                    result = {'results':self.engine.search(query.get('q',[''])[0])}
                elif path == '/api/checkpoints':
                    result = {'checkpoints':[{'name':k,'saved_at':v.get('saved_at')}
                                              for k,v in self.engine.checkpoints.items()]}
                elif path == '/api/events':
                    result = {'events':self.engine.events[-50:]}
                else:
                    return self._json({'error':'Unknown API route'},404)
                return self._json(result)
            except (ValueError, TypeError) as err:
                return self._json({'error':str(err)},400)
        # Only ship the GUI as a publicly readable asset. Other source files stay local.
        if path != '/frontend/index.html':
            self.send_error(404, 'Only the GUI file is served')
            return
        return super().do_GET()

    def do_POST(self):
        path=urlparse(self.path).path
        if not path.startswith('/api/'):
            return self._json({'error':'Not an API route'},404)
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
            return self._json({'error':'Requires application/json'},415)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 1 <= length <= 300_000:
                return self._json({'error':'Invalid body size (max 300KB)'},413)
            body=json.loads(self.rfile.read(length))
            if not isinstance(body,dict): raise ValueError('Expected JSON object')
            if path=='/api/int64':
                result=transform(body.get('value','0'),body.get('operation','xor'),body.get('key'),body.get('shift',13))
            elif path=='/api/generate':
                result=self.engine.generate(body.get('prompt',''))
            elif path=='/api/command':
                result=self.engine.command(body.get('expression',''))
            elif path=='/api/numeric':
                result=self.engine.numeric(body.get('numbers'),body.get('seed'))
            elif path=='/api/codec':
                result=self.engine.codec(body.get('operation'),body.get('data'),body.get('base',10),body.get('nonce'))
            elif path=='/api/train':
                result=self.engine.train(body.get('category'),body.get('text'))
            elif path=='/api/classify':
                result=self.engine.trainer.classify(body.get('text'))
            elif path=='/api/route':
                result=self.engine.route(body.get('target'),body.get('payload'))
            elif path=='/api/snap':
                result={'checkpoint':self.engine.snap(body.get('name'),body.get('data'))}
            else:
                return self._json({'error':'Unknown API route'},404)
            return self._json(result)
        except (ValueError,TypeError,KeyError,UnicodeDecodeError) as err:
            return self._json({'error':str(err)},400)
        except Exception:
            return self._json({'error':'Internal API error'},500)

def main():
    parser=argparse.ArgumentParser(description='ENCODEX GENIUS 64-bit localhost backend')
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    if args.host not in ('127.0.0.1','localhost','::1'):
        parser.error('Localhost binding only; this prototype is not network-facing')
    Handler.engine=GeniusEngine()
    httpd=ThreadingHTTPServer((args.host,args.port),Handler)
    print(f'ENCODEX 64-bit: http://{args.host}:{args.port}/frontend/index.html',flush=True)
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally: httpd.server_close()

if __name__=='__main__': main()
