using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
// ENCODEX GENIUS backend client (NET 8).
internal static class Program
{
    private static readonly HttpClient Client = new() { BaseAddress = new Uri(Environment.GetEnvironmentVariable("ENCODEX_API") ?? "http://127.0.0.1:8765") };
    private static async Task Main(string[] args)
    {
        string action = args.Length > 0 ? args[0] : "forge";
        string phrase = args.Length > 1 ? args[1] : "Design robotics training signal bridge";
        HttpResponseMessage response = action switch
        {
            "forge" => await Client.PostAsJsonAsync("/api/generate", new { prompt = phrase }),
            "command" => await Client.PostAsJsonAsync("/api/command", new { expression = phrase }),
            "encode" => await Client.PostAsJsonAsync("/api/codec", new { operation = "encode", data = phrase, @base = 16 }),
            "search" => await Client.GetAsync("/api/search?q=" + Uri.EscapeDataString(phrase)),
            _ => throw new ArgumentException("Use forge, search, encode or command")
        };
        string body = await response.Content.ReadAsStringAsync();
        response.EnsureSuccessStatusCode();
        Console.WriteLine(body);
    }
}
