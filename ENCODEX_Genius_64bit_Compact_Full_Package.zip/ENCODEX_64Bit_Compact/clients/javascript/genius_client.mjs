// Node.js 18+ headless API client (browser GUI lives in web/genius.js).
const action=process.argv[2]||'command';
const expression=process.argv[3]||'FLUX 2 3 5 8 13';
const url=(process.env.ENCODEX_API||'http://127.0.0.1:8765')+'/api/'+(action==='search'?'search?q='+encodeURIComponent(expression):action);
const response=await fetch(url, action==='search'?undefined:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(action==='command'?{expression}:{prompt:expression})});
if(!response.ok)throw Error('Backend error '+response.status+': '+await response.text());
console.log(JSON.stringify(await response.json(),null,2));
