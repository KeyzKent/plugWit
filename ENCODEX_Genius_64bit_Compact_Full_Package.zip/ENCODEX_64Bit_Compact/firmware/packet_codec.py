"""FluxNum v1 randomized-radix encoding, compatible with CircuitPython / CPython.

The substitution is reversible but NOT cryptographic encryption.
The nonce selects a deterministic shuffled alphabet; CRC-32 detects accidental errors.
"""
import os
import binascii

SYMBOLS = "0123456789ABCDEF"
BASES = (2, 8, 10, 16)
MASK = 0xFFFFFFFF


def bytes_to_hex(data):
    return binascii.hexlify(data).decode("ascii")


def hex_to_bytes(value):
    if not isinstance(value, str) or (len(value) % 2):
        raise ValueError("Hexadecimal input must have an even character count")
    return binascii.unhexlify(value)


def crc32(data):
    checksum = MASK
    for byte in data:
        checksum ^= byte
        for _ in range(8):
            if checksum & 1:
                checksum = (checksum >> 1) ^ 0xEDB88320
            else:
                checksum >>= 1
    return checksum ^ MASK


def digit_width(base):
    if base not in BASES:
        raise ValueError("Base must be 2, 8, 10 or 16")
    width = 1
    capacity = base
    while capacity <= 255:
        capacity *= base
        width += 1
    return width


def shuffled_alphabet(base, nonce):
    if base not in BASES:
        raise ValueError("Unsupported base")
    if (not isinstance(nonce, str) or len(nonce) != 8 or
            any(c not in "0123456789abcdefABCDEF" for c in nonce)):
        raise ValueError("Nonce must be 8 hex characters")
    state = (int(nonce, 16) ^ 0x9E3779B9) & MASK
    if state == 0:
        state = 0xA341316C
    alphabet = list(SYMBOLS[:base])
    for i in range(base - 1, 0, -1):
        state ^= (state << 13) & MASK
        state &= MASK
        state ^= (state >> 17)
        state &= MASK
        state ^= (state << 5) & MASK
        state &= MASK
        j = state % (i + 1)
        alphabet[i], alphabet[j] = alphabet[j], alphabet[i]
    return "".join(alphabet)


def encode(data, base=10, nonce=None):
    if not isinstance(data, (bytes, bytearray)):
        raise ValueError("Encoder requires bytes")
    width = digit_width(base)
    if nonce is None:
        nonce = bytes_to_hex(os.urandom(4))
    alphabet = shuffled_alphabet(base, nonce)
    output = []
    for byte in data:
        digits = [0] * width
        value = byte
        for i in range(width - 1, -1, -1):
            digits[i] = value % base
            value //= base
        for digit in digits:
            output.append(alphabet[digit])
    return {
        "v": 1,
        "base": base,
        "nonce": nonce.lower(),
        "count": len(data),
        "digits": "".join(output),
        "crc32": "%08x" % crc32(data),
    }


def decode(packet):
    if not isinstance(packet, dict) or packet.get("v") != 1:
        raise ValueError("Expected a FluxNum v1 packet")
    base = packet.get("base")
    width = digit_width(base)
    nonce = packet.get("nonce")
    alphabet = shuffled_alphabet(base, nonce)
    count = packet.get("count")
    digits = packet.get("digits")
    if not isinstance(count, int) or count < 0:
        raise ValueError("Invalid byte count")
    if not isinstance(digits, str) or len(digits) != count * width:
        raise ValueError("Payload length mismatch")
    if not isinstance(packet.get("crc32"), str) or len(packet["crc32"]) != 8:
        raise ValueError("CRC-32 field missing")
    out = bytearray()
    for start in range(0, len(digits), width):
        value = 0
        for c in digits[start:start + width]:
            index = alphabet.find(c)
            if index < 0:
                raise ValueError("Unexpected digit in payload")
            value = value * base + index
        if value > 255:
            raise ValueError("Decoded byte out of range")
        out.append(value)
    result = bytes(out)
    if "%08x" % crc32(result) != packet["crc32"].lower():
        raise ValueError("CRC-32 mismatch: corrupted packet")
    return result
