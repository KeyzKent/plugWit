# Board data contracts — realistic physical and virtual channels

## 1. Real USB-C chip protocol (unchanged)

Firmware `firmware/code.py` accepts newline-delimited UTF-8 JSON via the **USB CDC data endpoint**. The set of accepted commands is:

- `{"id":1,"cmd":"status"}`
- `{"id":2,"cmd":"encode","base":10,"data_hex":"48656c6c6f"}`
- `{"id":3,"cmd":"decode","packet":{"v":1,"base":10,"nonce":"1234abcd","count":5,"digits":"249020021021000","crc32":"f7d18982"}}`
- `{"id":4,"cmd":"random","count":16}`
- `{"id":5,"cmd":"self_test"}`

Every reply uses `{"id":N,"ok":true,...}` or `{"id":N,"ok":false,"error":"..."}`.

No existing firmware command changes pins, voltage, power, motors, radios, optical emitters or USB-PD. Sending a virtual `encodex.board_event.v1` payload to this firmware would produce an unknown-command error; therefore the GUI **does not attempt to send it**.

## 2. Encoded numeric stream

The packet includes `v`, `base` (2/8/10/16), `nonce` (8 hexadecimal symbols), `count`, `digits`, `crc32` (8 hexadecimal symbols). Each data byte uses a fixed-width radix representation whose alphabet is substituted using XorShift32+Fisher–Yates seeded by the public nonce. CRC-32 detects accidental errors; it is neither keyed authentication nor encryption.

## 3. Virtual hardware board events

GUI board packets look like:

```json
{"type":"encodex.board_event.v1","timestamp":"2026-11-18T00:00:00.000Z","target":"sensorhub","channel":"vision","mode":"virtual","payload":{"type":"encodex.vision.v1","dimensions":[160,90],"features":[0.2,0.3,0.4,0.3,0.1]}}
```

They can be exported as UTF-8 JSONL, pasted into the codec input, or sent to a **separately configured, user-trusted WebSocket server**. No robot, motor or logic board will act on them without a deliberately built receiver and validation layer.

## 4. Proposed real external integration (not included)

For each target board: (a) choose electrical transport USB CDC/BLE/I2C/SPI/Ethernet; (b) specify voltage isolation/protection and control circuitry; (c) define exact accepted message schema, bounds, device IDs, sequence numbers and acknowledgments; (d) implement device-specific firmware; (e) test actuator failsafes, network authorization and watch-dog. Future camera/video streams should use chunked media transport, not raw JSON lines to a constrained 256-byte codec endpoint.
