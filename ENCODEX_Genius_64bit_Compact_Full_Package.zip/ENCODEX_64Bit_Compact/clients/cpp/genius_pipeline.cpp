// C++17 reference for sharing the same v1 codec with C, Python and JavaScript.
// Compile with flux_codec.c and C++17; prints interoperable JSON packet.
#include <iostream>
#include <string>
#include <memory>
#include <cstdint>
#include "../c/flux_codec.h"
int main(int argc,char**argv){
    const std::string sample = argc>1?argv[1]:"ENCODEX C++ sensor bridge";
    std::unique_ptr<char, decltype(&std::free)> digits(nullptr,&std::free);
    char* raw=nullptr;std::uint32_t crc=0;
    const int base=16;const char* nonce="a1b2c3d4"; // fixed test nonce; production uses OS randomness
    if(flux_encode(reinterpret_cast<const unsigned char*>(sample.data()),sample.size(),base,nonce,&raw,&crc)){
        std::cerr<<"Failed to encode"<<std::endl;return 1;
    }
    digits.reset(raw);
    std::cout<<"{\"v\":1,\"base\":16,\"nonce\":\""<<nonce<<"\",\"count\":"<<sample.size()
             <<",\"digits\":\""<<digits.get()<<"\",\"crc32\":\"";
    char crcstr[9];std::snprintf(crcstr,sizeof(crcstr),"%08x",crc);
    std::cout<<crcstr<<"\"}"<<std::endl;
    unsigned char* restored=nullptr;
    if(flux_decode(base,nonce,digits.get(),sample.size(),crc,&restored))return 2;
    std::unique_ptr<unsigned char,decltype(&std::free)> owner(restored,&std::free);
    if(std::string(reinterpret_cast<char*>(restored),sample.size())!=sample)return 3;
    return 0;
}
