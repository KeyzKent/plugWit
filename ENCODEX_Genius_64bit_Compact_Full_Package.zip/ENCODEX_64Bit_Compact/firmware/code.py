"""FluxNum USB-C command monitor for CircuitPython native-USB microcontrollers.

Uses USB CDC data, not the Python REPL console. Newline-delimited JSON.
Designed for Adafruit QT Py RP2040. No electrical USB-C/PD control.
"""
import gc
import json
import os
import sys
import time
import usb_cdc
from packet_codec import encode, decode, bytes_to_hex, hex_to_bytes

MAX_BYTES = 256
MAX_LINE = 8192
VERSION = "1.0"
port = usb_cdc.data
if port is None:
    raise RuntimeError("Enable usb_cdc.data in boot.py, then reset the board")
port.timeout = 0
port.write_timeout = 1


def dispatch(request):
    if not isinstance(request, dict):
        raise ValueError("JSON request must be an object")
    cmd = request.get("cmd")
    if cmd == "status" or cmd == "hello":
        gc.collect()
        return {
            "name": "FluxNum Micro OS",
            "version": VERSION,
            "transport": "USB CDC data / JSONL",
            "platform": sys.platform,
            "uptime_seconds": int(time.monotonic()),
            "free_memory_bytes": gc.mem_free(),
            "max_bytes_per_request": MAX_BYTES,
            "bases": [2, 8, 10, 16],
            "commands": ["hello", "status", "encode", "decode", "random", "self_test"],
        }
    if cmd == "encode":
        data = hex_to_bytes(request.get("data_hex", ""))
        if len(data) > MAX_BYTES:
            raise ValueError("Limit is 256 input bytes per device command")
        return {"packet": encode(data, request.get("base", 10))}
    if cmd == "decode":
        packet = request.get("packet")
        if not isinstance(packet, dict) or packet.get("count", 0) > MAX_BYTES:
            raise ValueError("Packet exceeds 256-byte device limit")
        data = decode(packet)
        return {"data_hex": bytes_to_hex(data), "count": len(data)}
    if cmd == "random":
        count = request.get("count", 16)
        if not isinstance(count, int) or not 1 <= count <= 128:
            raise ValueError("Random count must be between 1 and 128")
        return {"data_hex": bytes_to_hex(os.urandom(count)), "count": count}
    if cmd == "self_test":
        sample = b"FluxNum/USB-C TEST\x00\xff"
        for base in (2, 8, 10, 16):
            packet = encode(sample, base, "1234abcd")
            if decode(packet) != sample:
                raise ValueError("Self-test failed")
        return {"passed": True, "bases_checked": [2, 8, 10, 16]}
    raise ValueError("Unknown command: %s" % cmd)


def respond(request):
    req_id = request.get("id") if isinstance(request, dict) else None
    try:
        result = dispatch(request)
        result["id"] = req_id
        result["ok"] = True
    except Exception as exc:
        result = {"id": req_id, "ok": False, "error": str(exc)}
    port.write((json.dumps(result) + "\n").encode("utf-8"))


buffer = bytearray()
while True:
    if port.in_waiting:
        incoming = port.read(min(port.in_waiting, 1024))
        if incoming:
            for byte in incoming:
                if byte == 10:  # LF
                    try:
                        request = json.loads(bytes(buffer).decode("utf-8"))
                        respond(request)
                    except Exception as exc:
                        port.write((json.dumps({"id": None, "ok": False,
                                                "error": str(exc)}) + "\n").encode("utf-8"))
                    buffer = bytearray()
                elif len(buffer) < MAX_LINE:
                    buffer.append(byte)
                else:
                    buffer = bytearray()
                    port.write(b'{"id":null,"ok":false,"error":"Line too long"}\n')
    else:
        time.sleep(0.005)
