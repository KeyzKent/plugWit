# Earlier ENCODEX / InterSphere software concepts mapped to the integrated GUI

## Working in current browser build

- **Symmetrical multi-window interface:** onyx-black with lavender, crimson and warm brown; mirrored workstation panels, active diagnostics, mobile navigation.
- **Internet translation I/O:** Base64, Base64URL, hexadecimal, binary byte strings, URL percent encoding, JSON strings and decimal HTML entities, with a separate randomized-radix FluxNum packet encoder.
- **OS-like serial monitor:** USB-C RP2040 CDC status, self-test, random output, reversible packet encode/decode, local fallback, save points.
- **Multimedia workflow:** photo/video import, webcam capture where permitted, grayscale/brightness/mean-color and frame-difference descriptor computation, rendered image PNG, WebM video output via browser MediaRecorder when supported.
- **Robot learning:** manual/vision/haptic 5D labeled records, simple nearest-centroid learner, action labels `idle`, `move_forward`, `turn_left`, `turn_right`, `dock`, `repair`, `pacify`, `custom`, JSONL dataset interchange.
- **Haptic I/O:** pointer X/Y/pressure, pulse waveform, local Vibration API request when supported.
- **Logic board/flux:** virtual sensor bus routing, typed JSONL events, simulated load and application activity, motherboard/pin architecture diagram.
- **Frequency/photonic concepts:** virtual waveform, ADC quantization, optical/electrical/pulse/airflow/brainwave signal type descriptors, mic amplitude meter where permitted.
- **Character shop / forge:** multiple reference images, on-screen sketch, trait controls and named characters, PNG/JSON/very basic OBJ geometry exports.
- **Levitating city + docking:** isometric floating city/tower architecture, stylized spacecraft animations, orbit/space modes, repair service queue and exportable world state, 2.5D pacify arena with escalating robot waves and reward count.
- **IDE / tools:** HTML/CSS/JS web preview sandbox, template/edit/export for Python, Java, C, C++, C#, Swift, Android Java, Rust, Ruby, PHP/WordPress, Unix shell and Windows batch, browser speech recognition dictation when supported, JS syntax test.
- **Network I/O:** manual WebSocket URL + explicit JSONL send, no automatic remote transfer.

## Not implemented or requiring future hardware/SDKs

- **True multicompiler and auto-correction AI:** needs a secure server agent, isolated language toolchains and integration with authenticated developer services.
- **Native apps and bootable OS (ISO, APK, DMG, EXE):** this delivery contains portable source, not signed/compiled native packages.
- **Brain-computer interface / EEG:** requires compatible certified sensor hardware, vendor SDKs and consent protocols; UI type selector is only conceptual.
- **USB-C inline bridge / PD / FPGA or PCIe:** a passive cable/e-marker is not programmable as proposed; needs a purpose-built two-port controller board.
- **Photodiode quartz nanotech, lasers, plasma, optical telemetry, electrical propulsion:** no physical high-voltage/radiating control; simulation only.
- **Fully autonomous robotics, motion/pose-capture models and external haptic vest:** needs drivers, real pose estimation, safety enforcement, calibrations, physical testing.
- **Multiplayer 3D galaxy, Vision Pro/Quest applications, large procedural worlds:** separate game engine and graphics SDK builds required.
- **Blockchain/mining/cryptocurrency economy and validators:** not present in this prototype; would require independently audited networking, ledger code and consensus design.
- **Quantum/teleportation/astral/dimensional concepts:** no verified physical implementations; optional story/world research themes rather than actual device capabilities.

## Example production architecture

```text
iPhone / Android / macOS / Windows / Web GUI
            │
Local ENCODEX web sandbox ───── Remote optional LLM/build service (future)
            │
       FluxNum codec v1
            │
      USB CDC JSONL ─── RP2040 code.py (existing codec commands)
            │
      WebSocket JSONL ─ Custom board gateway (not supplied)
                              │
               Dedicated protected I/O controller
                              │
                  Validated sensor or motor interfaces
```

Preserve a strong separation of **measured physical inputs**, **simulated values**, **software-derived values**, and **actuator commands**; all currently simulated fields are labeled accordingly.
