#include "flux_codec.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

static const char HEX[]="0123456789ABCDEF";
int flux_digit_width(int base) {
    if(base!=2 && base!=8 && base!=10 && base!=16) return 0;
    int width=1,capacity=base;
    while(capacity<=255){capacity*=base;width++;}
    return width;
}
uint32_t flux_crc32(const unsigned char *data,size_t length){
    uint32_t crc=0xffffffffU;
    for(size_t i=0;i<length;i++){
        crc^=data[i];
        for(int k=0;k<8;k++)crc=(crc&1U)?(crc>>1)^0xedb88320U:(crc>>1);
    }
    return crc^0xffffffffU;
}
static int make_alphabet(int base,const char *nonce,char *alphabet){
    if(!flux_digit_width(base)||!nonce||strlen(nonce)!=8)return 0;
    uint32_t v=0;
    for(int i=0;i<8;i++){
        char c=nonce[i];int digit;
        if(c>='0'&&c<='9')digit=c-'0';
        else if(c>='a'&&c<='f')digit=c-'a'+10;
        else if(c>='A'&&c<='F')digit=c-'A'+10;
        else return 0;
        v=(v<<4)|(uint32_t)digit;
    }
    uint32_t state=v^0x9e3779b9U;
    if(state==0)state=0xa341316cU;
    memcpy(alphabet,HEX,(size_t)base);alphabet[base]='\0';
    for(int i=base-1;i>0;i--){
        state^=state<<13;state^=state>>17;state^=state<<5;
        int j=(int)(state%(uint32_t)(i+1));
        char tmp=alphabet[i];alphabet[i]=alphabet[j];alphabet[j]=tmp;
    }
    return 1;
}
int flux_encode(const unsigned char *data,size_t length,int base,const char *nonce,char **digits,uint32_t *checksum){
    int width=flux_digit_width(base);
    char alphabet[17];
    if(!digits||!checksum||(!data&&length)||!width||!make_alphabet(base,nonce,alphabet)||length>65536 || length>(SIZE_MAX-1)/(size_t)width)return -1;
    char *out=(char*)malloc(length*(size_t)width+1);
    if(!out)return -2;
    for(size_t k=0;k<length;k++){
        unsigned value=data[k];
        for(int j=width-1;j>=0;j--){out[k*(size_t)width+(size_t)j]=alphabet[value%(unsigned)base];value/=(unsigned)base;}
    }
    out[length*(size_t)width]='\0';
    *checksum=flux_crc32(data,length);
    *digits=out;
    return 0;
}
int flux_decode(int base,const char *nonce,const char *digits,size_t count,uint32_t expected,unsigned char **output){
    int width=flux_digit_width(base);char alphabet[17];
    if(!output||!digits||!width||!make_alphabet(base,nonce,alphabet)||count>65536||count>(SIZE_MAX-1)/(size_t)width||strlen(digits)!=count*(size_t)width)return -1;
    unsigned char *out=(unsigned char*)malloc(count+1);
    if(!out)return -2;
    for(size_t k=0;k<count;k++){
        unsigned value=0;
        for(int j=0;j<width;j++){
            const char *p=strchr(alphabet,digits[k*(size_t)width+(size_t)j]);
            if(!p){free(out);return -3;}
            value=value*(unsigned)base+(unsigned)(p-alphabet);
        }
        if(value>255){free(out);return -4;}
        out[k]=(unsigned char)value;
    }
    out[count]='\0';
    if(flux_crc32(out,count)!=expected){free(out);return -5;}
    *output=out;return 0;
}
