"""Exact unsigned 64-bit word manipulations. No hardware access or crypto."""
import re
import secrets

MASK = (1 << 64) - 1

def parse_word(value, label='value'):
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError(f'{label} must be an integer string (decimal or 0x hex)')
    s = str(value).strip().replace('_', '')
    if not re.fullmatch(r'(0[xX][0-9a-fA-F]+|[0-9]+)', s):
        raise ValueError(f'{label} must be unsigned decimal or 0x hex')
    number = int(s, 16 if s.lower().startswith('0x') else 10)
    if not 0 <= number <= MASK:
        raise ValueError(f'{label} must be between 0 and 2^64 - 1')
    return number

def fields(value):
    value &= MASK
    return {'unsigned': str(value), 'signed': str(value if value < (1 << 63) else value-(1 << 64)),
            'hex': f'0x{value:016X}', 'binary': f'{value:064b}', 'ones': value.bit_count()}

def transform(value, operation='xor', key=None, shift=13):
    x = parse_word(value)
    if operation not in ('xor', 'rotate', 'add'):
        raise ValueError('Operation must be xor, rotate, or add')
    if not isinstance(shift, int) or isinstance(shift, bool) or not 0 <= shift < 64:
        raise ValueError('Rotation must be 0–63')
    k = secrets.randbits(64) if key is None or key == '' else parse_word(key, 'key')
    if operation == 'xor':
        out = x ^ k
        recovered = out ^ k
    elif operation == 'rotate':
        out = ((x << shift) | (x >> (64 - shift if shift else 64))) & MASK
        recovered = ((out >> shift) | (out << (64 - shift if shift else 64))) & MASK
    else:
        out = (x + k) & MASK
        recovered = (out - k) & MASK
    return {'mode': 'EXACT_UINT64', 'operation': operation, 'input': fields(x),
            'key': fields(k), 'shift': shift, 'result': fields(out),
            'recovered': fields(recovered), 'round_trip': recovered == x,
            'note': 'Word transforms are reversible numeric operations, not encryption or physical hardware control.'}
