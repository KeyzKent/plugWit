"""Copy to CIRCUITPY root. Enable the second USB CDC data interface."""
import usb_cdc
usb_cdc.enable(console=True, data=True)
