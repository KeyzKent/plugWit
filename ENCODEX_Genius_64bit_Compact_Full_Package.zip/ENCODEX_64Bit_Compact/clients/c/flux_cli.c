/* Portable C99 numeric codec; real USB connection is implemented separately. */
#include "flux_codec.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

static int nonce_random(char *out){
    unsigned char bytes[4];
#ifdef _WIN32
    for(int i=0;i<4;i++){unsigned int v=0;if(rand_s(&v))return 0;bytes[i]=(unsigned char)(v&255U);}
#else
    FILE *fp=fopen("/dev/urandom","rb");
    if(!fp)return 0;
    size_t n=fread(bytes,1,4,fp);fclose(fp);
    if(n!=4)return 0;
#endif
    snprintf(out,9,"%02x%02x%02x%02x",bytes[0],bytes[1],bytes[2],bytes[3]);return 1;
}
int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"Usage: %s encode BASE TEXT [NONCE_HEX8] | decode BASE NONCE DIGITS CRC32_HEX\n",argv[0]);return 2;}
    int base=atoi(argv[2]);
    if(!flux_digit_width(base)){fputs("Base must be 2 8 10 16\n",stderr);return 2;}
    if(strcmp(argv[1],"encode")==0){
        if(argc<4){fputs("Missing TEXT\n",stderr);return 2;}
        char generated[9];const char *nonce=argc>=5?argv[4]:generated;
        if(argc<5&&!nonce_random(generated)){fputs("Secure OS randomness unavailable; supply an explicit nonce\n",stderr);return 3;}
        char *digits=0;uint32_t crc=0;size_t n=strlen(argv[3]);
        if(flux_encode((const unsigned char*)argv[3],n,base,nonce,&digits,&crc)){fputs("Encoding failed\n",stderr);return 3;}
        printf("{\"v\":1,\"base\":%d,\"nonce\":\"%s\",\"count\":%zu,\"digits\":\"%s\",\"crc32\":\"%08x\"}\n",base,nonce,n,digits,crc);
        free(digits);return 0;
    }
    if(strcmp(argv[1],"decode")==0){
        if(argc<6){fputs("Need BASE NONCE DIGITS CRC32_HEX\n",stderr);return 2;}
        int width=flux_digit_width(base);size_t dlen=strlen(argv[4]);
        if(dlen%(size_t)width){fputs("Wrong digit length\n",stderr);return 2;}
        char *end;unsigned long expected=strtoul(argv[5],&end,16);
        if(*end||expected>UINT32_MAX){fputs("Invalid CRC32 value\n",stderr);return 2;}
        unsigned char *data=0;size_t count=dlen/(size_t)width;
        int status=flux_decode(base,argv[3],argv[4],count,(uint32_t)expected,&data);
        if(status){fprintf(stderr,"Decode / integrity failure: %d\n",status);return 3;}
        fwrite(data,1,count,stdout);fputc('\n',stdout);free(data);return 0;
    }
    fputs("Choose encode or decode\n",stderr);return 2;
}
