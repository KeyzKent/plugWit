/* macOS Foundation Objective-C client. Requires Xcode Command Line Tools.
   clang -fobjc-arc -framework Foundation GeniusObjectiveC.m -o genius-objc */
#import <Foundation/Foundation.h>
int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSString *phrase = argc > 1 ? [NSString stringWithUTF8String:argv[1]] : @"camera USB-C robot training";
        NSDictionary *payload = @{ @"prompt": phrase };
        NSError *error = nil;
        NSData *data = [NSJSONSerialization dataWithJSONObject:payload options:0 error:&error];
        if (!data || error) { NSLog(@"JSON error: %@", error); return 1; }
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:
            [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/generate", [[NSProcessInfo processInfo] environment][@"ENCODEX_API"] ?: @"http://127.0.0.1:8765"]]];
        request.HTTPMethod = @"POST";
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        request.HTTPBody = data;
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        __block NSData *received = nil;
        __block NSError *failure = nil;
        NSURLSessionDataTask *task = [[NSURLSession sharedSession]
            dataTaskWithRequest:request completionHandler:^(NSData *body, NSURLResponse *response, NSError *err) {
                received = body; failure = err; dispatch_semaphore_signal(semaphore);
            }];
        [task resume];
        if (dispatch_semaphore_wait(semaphore, dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC))) {
            NSLog(@"Local server timed out"); [task cancel]; return 2;
        }
        if (failure) { NSLog(@"Request failed: %@", failure); return 3; }
        id result = [NSJSONSerialization JSONObjectWithData:received options:0 error:&error];
        if (error) { NSLog(@"Response parse failed: %@", error); return 4; }
        NSLog(@"ENCODEX GENIUS: %@", result);
    }
    return 0;
}
