import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from backend.engine import GeniusEngine
from firmware.packet_codec import decode

ROOT=Path(__file__).resolve().parents[1]
class GeniusTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.engine=GeniusEngine(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def test_search(self):
        self.assertTrue(self.engine.search('usb c microcontroller sensor'))
    def test_generate(self):
        result=self.engine.generate('Optical robot motion sensor')
        self.assertEqual(result['mode'],'local_retrieval_draft')
        self.assertTrue(result['sources'])
    def test_commands(self):
        self.assertTrue(self.engine.command('LENS camera')['results'])
        self.assertEqual(self.engine.command('FLUX 2 4 8')['count'],3)
        self.assertEqual(self.engine.command('ROUTE robot | {"motor":0}')['mode'],'SIMULATION')
        self.assertEqual(self.engine.command('MIRROR USB-C')['term'],'MIRROR')
        self.assertEqual(self.engine.command('SNAP project 1')['term'],'SNAP')
    def test_invalid_numbers(self):
        with self.assertRaises(ValueError):self.engine.numeric([float('nan')])
        with self.assertRaises(ValueError):self.engine.command('FLUX not_numbers')
    def test_repeatable_seed(self):
        a=self.engine.numeric([1,2,3,4,5],123)
        b=self.engine.numeric([1,2,3,4,5],123)
        self.assertEqual(a,b)
    def test_codec_bases(self):
        for base in (2,8,10,16):
            data='USB-C ⇢ ENCODEX 🌐'
            p=self.engine.codec('encode',data,base,'abcd1234')['packet']
            self.assertEqual(self.engine.codec('decode',p)['text'],data)
            self.assertEqual(decode(p),data.encode())
    def test_classifier_training_checkpoint(self):
        self.engine.train('testname','humanoid motion sensor pan')
        self.assertEqual(self.engine.trainer.classify('humanoid')['method'],'multinomial_naive_bayes')
        self.engine.snap('snapshot',{'value':10})
        engine2=GeniusEngine(self.temp.name)
        self.assertEqual(engine2.snap('snapshot')['data']['value'],10)
        self.assertTrue(any(x['category']=='testname' for x in engine2.trainer.examples))
    def test_route_rejects_hardware(self):
        with self.assertRaises(ValueError):self.engine.route('usb-power-delivery',{'voltage':99})
    def test_c_cli_cross_language(self):
        binary=ROOT/'build/fluxnum-c'
        if not binary.exists():self.skipTest('C compiler executable not present')
        for base in (2,8,10,16):
            p=json.loads(subprocess.check_output([str(binary),'encode',str(base),'Hello🌐','99aabbcc'],text=True))
            self.assertEqual(decode(p).decode('utf-8'),'Hello🌐')
            result=subprocess.check_output([str(binary),'decode',str(base),'99aabbcc',p['digits'],p['crc32']],text=True)
            self.assertEqual(result.strip(),'Hello🌐')
if __name__=='__main__':unittest.main()
