"""Small transparent multinomial Naive Bayes classifier. Not a neural network."""
from collections import Counter, defaultdict
import math
import re


def words(value):
    return re.findall(r"[a-z0-9_]+", str(value).lower())[:512]


class TextClassifier:
    def __init__(self, examples=None):
        self.examples = list(examples or [])

    def train(self, category, phrase):
        if not isinstance(category, str) or not re.fullmatch(r"[a-zA-Z][\w -]{0,39}", category):
            raise ValueError("Category must be 1–40 letters/numbers/spaces")
        if not isinstance(phrase, str) or not phrase.strip() or len(phrase) > 2048:
            raise ValueError("Training text must be 1–2,048 characters")
        if len(self.examples) >= 1000:
            raise ValueError("Training bank capacity is 1,000 examples")
        record = {"category": category.strip().lower(), "text": phrase.strip()}
        self.examples.append(record)
        return record

    def classify(self, phrase):
        if not isinstance(phrase, str) or len(phrase) > 2048:
            raise ValueError("Classification text must be at most 2,048 characters")
        grouped = defaultdict(Counter)
        total = Counter()
        vocab = set()
        for record in self.examples:
            cat = record["category"]
            tokens = words(record["text"])
            grouped[cat].update(tokens)
            total[cat] += 1
            vocab.update(tokens)
        if not total:
            return {"category": "untrained", "scores": [], "method": "multinomial_naive_bayes"}
        total_docs = sum(total.values())
        scores = {}
        for cat, counts in grouped.items():
            sum_words = sum(counts.values())
            value = math.log(total[cat] / total_docs)
            for word in words(phrase):
                value += math.log((counts[word] + 1) / (sum_words + len(vocab) + 1))
            scores[cat] = value
        maximum = max(scores.values())
        weights = {k: math.exp(v - maximum) for k, v in scores.items()}
        divisor = sum(weights.values())
        ranked = sorted(({"category": k, "probability": round(v / divisor, 4)} for k, v in weights.items()), key=lambda x: -x["probability"])
        return {"category": ranked[0]["category"], "scores": ranked, "method": "multinomial_naive_bayes", "training_count": len(self.examples)}
