# Platform, SDK and file-extension notes

- **Desktop browsers:** Chrome/Edge recommended for optional Web Serial; Firefox/Safari support most local simulation and codec features without Web Serial. Use localhost or HTTPS for permissions and predictable storage.
- **iOS/iPadOS:** Safari does not support Web Serial; use the numeric codec/GUI in simulation. Webcam, speech recognition, WebM video recording and vibration APIs may be unsupported or permission-restricted. Hosting over HTTPS is recommended; simply previewing a local HTML file in Files may not run scripts.
- **Android:** Chrome may expose different combinations of camera, USB, microphone, Web Serial and vibration features; no APK is in this bundle. Native USB host access would need Android Studio, USB Host API and manifest permissions.
- **Windows/macOS/Linux:** `python host/numeric_os.py` provides serial host access with pyserial after installing `host/requirements.txt`. Use the actual DATA CDC port.
- **Code editor export extensions:** `.html`, `.css`, `.js`, `.py`, `.java`, `.c`, `.cpp`, `.cs`, `.swift`, `.rs`, `.rb`, `.php`, `.sh`, `.bat` plus `.json`, `.jsonl`, `.png`, `.webm`, `.obj` supported as app-generated data/artifacts.
- **Native toolchains (external):** Xcode/Swift for iOS `.app`/`.ipa`; Android Studio for `.apk`/`.aab`; Visual Studio/.NET for C#; gcc/clang for C/C++; JDK for Java; rustc/Cargo for Rust; Python interpreter for Python; PHP runtime and WordPress SDK for PHP plugins. Those toolchains are **not embedded in the GUI**.

This package provides editable source and a browser application. The firmware is source code that needs CircuitPython flashed to a compatible board; it is not a ready-made USB cable firmware image.
