import unittest
from backend.int64 import transform,parse_word,MASK
class TestWord64(unittest.TestCase):
    def test_roundtrip(self):
        for operation in ('xor','rotate','add'):
            for value in ('0','1','0xFEDCBA9876543210',str(MASK)):
                for shift in (0,13,63):
                    result=transform(value,operation,'0xA1A2A3A4A5A6A7A8',shift)
                    self.assertTrue(result['round_trip'])
                    self.assertEqual(int(result['recovered']['unsigned']),parse_word(value))
    def test_bounds(self):
        for bad in ('-1',str(1<<64),'nope','3.2'):
            with self.assertRaises(ValueError): parse_word(bad)
    def test_sign(self):
        self.assertEqual(transform(str(MASK),'xor','0')['input']['signed'],'-1')
if __name__=='__main__': unittest.main()
