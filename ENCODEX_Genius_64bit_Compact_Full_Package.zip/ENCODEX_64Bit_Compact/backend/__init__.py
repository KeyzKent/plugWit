"""ENCODEX GENIUS local backend."""
