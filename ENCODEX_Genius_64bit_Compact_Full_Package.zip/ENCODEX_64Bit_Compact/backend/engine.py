"""Local retrieval, analogy commands, FluxNum v1 compatibility, and ML training."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import base64
import json
import math
import random
import re
import secrets
import shlex
import statistics
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "firmware"))
from packet_codec import encode, decode  # original v1 USB codec, not a new incompatible format
from backend.trainer import TextClassifier, words

ANALOGIES = {
    "LENS": "Search indexed local project documents and technical concepts",
    "FORGE": "Synthesize a grounded design draft from retrieved project excerpts",
    "MIRROR": "Describe and compare a project subsystem through an analogy",
    "FLUX": "Calculate numerical signal statistics, normalized values, and seeded shuffle",
    "TRAIN": "Teach the local text classifier by labeled examples",
    "CLASSIFY": "Predict a learned category from typed text",
    "ROUTE": "Record a virtual JSON signal event; never actuates connected hardware",
    "SNAP": "Store a named backend project checkpoint",
}
DEFAULT_EXAMPLES = [
    {"category": "robotics", "text": "Train servo motion capture feedback robot camera joint movement"},
    {"category": "robotics", "text": "Classify robotic vision and gestures with sensor data"},
    {"category": "hardware", "text": "USB-C chip RP2040 photodiode ADC DAC logic board interfaces"},
    {"category": "hardware", "text": "Encode sensor input and route virtual hardware outputs"},
    {"category": "world", "text": "Construct levitating cities spacecraft docks and open world characters"},
    {"category": "world", "text": "Design buildings and explore space with 3D avatar"},
    {"category": "codec", "text": "Randomized numeric encoder decoder base 16 packets CRC checksum"},
    {"category": "codec", "text": "Convert binary octal decimal hexadecimal numerical system"},
    {"category": "media", "text": "Camera input image output video motion capture frames"},
    {"category": "media", "text": "Edit animated character drawings and motion video"},
    {"category": "ide", "text": "Java JavaScript HTML CSS Python C C++ Csharp ObjectiveC code"},
    {"category": "ide", "text": "Compiler software programming source code universal IDE"},
]

class GeniusEngine:
    def __init__(self, data_dir=None):
        self.root = ROOT
        self.data_dir = Path(data_dir or ROOT / "data")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.training_file = self.data_dir / "training.json"
        self.snap_file = self.data_dir / "checkpoints.json"
        self.events = []
        self.checkpoints = self._read_json(self.snap_file, {})
        training = self._read_json(self.training_file, DEFAULT_EXAMPLES)
        self.trainer = TextClassifier(training if isinstance(training, list) else DEFAULT_EXAMPLES)
        self.documents = self._documents()

    @staticmethod
    def _read_json(path, fallback):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return fallback

    @staticmethod
    def _write_json(path, obj):
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(path)

    def _documents(self):
        examples = [
            ("GENIUS term glossary", "LENS searches local project text. FORGE drafts a grounded architecture idea. MIRROR explains subsystems with analogies. FLUX works with sample numbers. TRAIN labels examples. CLASSIFY predicts labels. ROUTE only sends virtual events. SNAP stores checkpoints."),
            ("Analogies for software", "The encoder is a translator, the decoder is an interpreter, the USB-C microcontroller is a bridge, the sensor bus is a nervous system, the GUI is a cockpit, and the training bank is a notebook. This is a conceptual analogy, not a claim of machine intelligence."),
        ]
        docs = [{"id": f"builtin-{i}", "title": t, "text": s, "path": "built-in"} for i,(t,s) in enumerate(examples)]
        for file in [ROOT / "README.md", *sorted((ROOT / "docs").glob("*.md"))]:
            try:
                content = file.read_text(encoding="utf-8")[:26000]
            except OSError:
                continue
            for idx, section in enumerate(re.split(r"(?m)^#{1,3}\s+", content)):
                clean = re.sub(r"[`#*]", "", section).strip()
                if len(clean) > 30:
                    title = clean.splitlines()[0][:90]
                    docs.append({"id": f"{file.stem}-{idx}", "title": title,
                                 "text": clean[:2800], "path": str(file.relative_to(ROOT))})
        return docs

    def search(self, query, limit=6):
        if not isinstance(query, str) or len(query) > 500:
            raise ValueError("Search query must be up to 500 characters")
        tokens = words(query)
        if not tokens:
            return []
        scored = []
        for doc in self.documents:
            title = Counter(words(doc["title"]))
            body = Counter(words(doc["text"]))
            score = sum((title[t] * 7 + min(body[t], 6)) for t in set(tokens))
            if score:
                scored.append((score, doc))
        scored.sort(key=lambda pair: (-pair[0], pair[1]["title"]))
        results = []
        for score, doc in scored[:max(1, min(int(limit), 12))]:
            sentences = re.split(r"(?<=[.!?])\s+|\n+", doc["text"])
            snippets = sorted((s for s in sentences if s.strip()),
                              key=lambda s: sum(s.lower().count(t) for t in set(tokens)), reverse=True)
            excerpt = " ".join(snippets[:2])[:390]
            results.append({"id": doc["id"], "title": doc["title"], "snippet": excerpt,
                            "score": score, "source": doc["path"]})
        return results

    def generate(self, prompt):
        if not isinstance(prompt, str) or len(prompt) > 500:
            raise ValueError("Prompt must be up to 500 characters")
        hits = self.search(prompt, 4)
        label = self.trainer.classify(prompt)["category"]
        if not hits:
            return {"mode": "local_retrieval_draft", "answer": "No matching project documentation found. Add relevant documents or provide a more specific design question.", "sources": [], "category": label}
        phrases = [h["snippet"].strip() for h in hits[:3] if h["snippet"].strip()]
        answer = ("Design question: " + prompt.strip() + "\n\n" +
                  "Relevant project material:\n" + "\n".join("• " + s for s in phrases) + "\n\n" +
                  "Suggested prototype flow: input → LENS retrieval → FLUX/FluxNum processing → virtual ROUTE → GUI visualization → SNAP checkpoint. " +
                  "Validate device-specific commands before any physical hardware integration.")
        return {"mode": "local_retrieval_draft", "answer": answer, "sources": [h["source"] for h in hits], "category": label}

    def numeric(self, numbers, seed=None):
        if not isinstance(numbers, list) or not numbers or len(numbers) > 2048:
            raise ValueError("Provide between 1 and 2048 numbers")
        if any(isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n) or abs(n)>1e12 for n in numbers):
            raise ValueError("Numbers must be finite and within ±10^12")
        if seed is None:
            seed = secrets.randbits(32)
        if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0 or seed > 0xffffffff:
            raise ValueError("Seed must be a 32-bit unsigned integer")
        rng = random.Random(seed)
        shuffled = list(numbers)
        rng.shuffle(shuffled)
        average = statistics.fmean(numbers)
        deviation = statistics.pstdev(numbers)
        lower, upper = min(numbers), max(numbers)
        span = upper - lower
        normal = [round((float(n)-lower)/span, 6) if span else 0.0 for n in numbers]
        return {"seed": seed, "count": len(numbers), "mean": average, "stddev": deviation,
                "min": lower, "max": upper, "normalized": normal, "shuffled": shuffled,
                "note": "Seeded shuffle is reproducible numerical processing, not secure encryption or measured device flux."}

    def codec(self, operation, data, base=10, nonce=None):
        if operation == "encode":
            if not isinstance(data, str) or len(data.encode("utf-8")) > 65536:
                raise ValueError("Text input must be at most 65,536 UTF-8 bytes")
            return {"packet": encode(data.encode("utf-8"), int(base), nonce)}
        if operation == "decode":
            if not isinstance(data, dict) or data.get("count", 0)>65536:
                raise ValueError("Invalid or oversized FluxNum packet")
            raw = decode(data)
            return {"text": raw.decode("utf-8", errors="replace"), "data_base64": base64.b64encode(raw).decode("ascii"), "bytes": len(raw)}
        raise ValueError("Operation must be encode or decode")

    def train(self, label, example):
        with self.lock:
            record = self.trainer.train(label, example)
            self._write_json(self.training_file, self.trainer.examples)
            return {"trained": record, "training_count": len(self.trainer.examples)}

    def route(self, target, payload):
        if target not in ("camera", "board", "robot", "haptic", "spectrum", "world", "dock", "ide", "usb-sim"):
            raise ValueError("Unsupported virtual target")
        if not isinstance(payload, (dict, str, int, float, list, bool)):
            raise ValueError("Route payload must be JSON data")
        with self.lock:
            event = {"target": target, "payload": payload, "mode": "SIMULATION",
                     "timestamp": datetime.now(timezone.utc).isoformat()}
            self.events.append(event)
            self.events = self.events[-80:]
            return event

    def snap(self, name, snapshot=None):
        if not isinstance(name, str) or not re.fullmatch(r"[\w -]{1,70}", name):
            raise ValueError("Checkpoint name needs 1–70 letters/numbers/spaces")
        if snapshot is not None and len(json.dumps(snapshot)) > 250000:
            raise ValueError("Checkpoint exceeds 250KB")
        with self.lock:
            if snapshot is None:
                return self.checkpoints.get(name)
            self.checkpoints[name] = {"saved_at": datetime.now(timezone.utc).isoformat(), "data": snapshot}
            if len(self.checkpoints) > 50:
                self.checkpoints.pop(next(iter(self.checkpoints)))
            self._write_json(self.snap_file, self.checkpoints)
            return self.checkpoints[name]

    def command(self, expression):
        if not isinstance(expression, str) or len(expression)>3000:
            raise ValueError("Command length must be at most 3,000")
        text = expression.strip()
        if not text:
            raise ValueError("Enter a GENIUS term command")
        command, _, argument = text.partition(" ")
        command = command.upper().strip()
        argument = argument.strip()
        if command == "LENS": return {"term": command, "results": self.search(argument)}
        if command == "FORGE": return {"term": command, **self.generate(argument)}
        if command == "MIRROR":
            return {"term": command, "analogy": f"{argument or 'Your subsystem'} is like a bridge: inputs are interpreted, processed, checked, and routed to a destination. A bridge analogy guides architecture but does not guarantee device compatibility."}
        if command == "FLUX":
            bits = [p for p in re.split(r"[\s,]+", argument) if p]
            try: values = [float(p) for p in bits]
            except ValueError: raise ValueError("FLUX expects numbers separated by spaces or commas")
            return {"term": command, **self.numeric(values)}
        if command == "TRAIN":
            label, sep, example = argument.partition("|")
            if not sep: raise ValueError("Syntax: TRAIN robotics | servo motion data")
            return {"term": command, **self.train(label.strip(), example.strip())}
        if command == "CLASSIFY": return {"term": command, **self.trainer.classify(argument)}
        if command == "ROUTE":
            target, sep, payload = argument.partition("|")
            if not sep: raise ValueError("Syntax: ROUTE robot | {\"signal\":3}")
            try: value = json.loads(payload)
            except json.JSONDecodeError: value = payload.strip()
            return {"term": command, **self.route(target.strip(), value)}
        if command == "SNAP": return {"term": command, "checkpoint": self.snap(argument, {"from": "command", "event_count": len(self.events)})}
        raise ValueError("Unknown term. Try LENS, FORGE, MIRROR, FLUX, TRAIN, CLASSIFY, ROUTE, SNAP")
